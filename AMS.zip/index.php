<?php
$title = "AMS";
include 'files/header.php';
?>

<div class="container">
	<div class="row">
		<div class="col-8">
			<div class="tutorial theBox mt-4 py-4 px-3">
				<h1>Please Enter Your ID Card</h1>
			</div>
		</div>
		<div class="col-8" id="userResult">
			<div class="row">
				<div class="col-4">
					<div class="profile theBox">
						<div class="roundProfile mb-4 p-2">
                        	<img class="userImage" src="https://lh3.googleusercontent.com/a-/AOh14GicZC9Yq5TLPgrnqodpLApUGrYS_8nbazLKg4lkMA=s300-c" alt="Jishan hoshen">
                    	</div>
					</div>
				</div>
				<div class="col-8">
					<div class="bio theBox py-4 px-3 mt-4">
						<div class="row">
							<div class="col-3 fw-bold" id="empName">Name</div>
							<div class="col-9" id="empNameVal"></div>
						</div>
						<div class="row mt-2">
							<div class="col-3 fw-bold" id="emlDep">Depertment</div>
							<div class="col-9" id="emlDepVal"></div>
						</div>
						<div class="row mt-2">
							<div class="col-3 fw-bold" id="emlJob">Job</div>
							<div class="col-9" id="emlJobVal"></div>
						</div>
						<div class="row mt-2">
							<div class="col-3 fw-bold" id="emlBirth">Birth</div>
							<div class="col-9" id="emlBirthVal"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<div class="details theBox py-4 px-3">
						<div class="row mt-2">
							<div class="col-3 fw-bold" id="empNid">NID</div>
							<div class="col-9" id="empNidVal"></div>
						</div>
						<div class="row mt-2">
							<div class="col-3 fw-bold" id="empPhone">Phone </div>
							<div class="col-9" id="empPhoneVal"></div>
						</div>
						<div class="row mt-2">
							<div class="col-3 fw-bold" id="empAddr">Address </div>
							<div class="col-9" id="empAddrVal"></div>
						</div>
						<div class="row mt-2">
							<div class="col-3 fw-bold" id="empEmail">Email</div>
							<div class="col-9" id="empEmailVal"></div>
						</div>
						<div class="row mt-2">
							<div class="col-3 fw-bold" id="empWeb">Website</div>
							<div class="col-9" id="empWebVal"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-4">
			<div class="scanner theBox mt-4">
				<video id="preview" width="100%"></video>
			</div>
			<div class="scandata theBox mt-4">
				<div class="form-outline">
				  <input type="text" name="text" id="qrcode" placeholder="scan qrcode" class="form-control" />
				</div>
			</div>
			<div class="scanMessage mt-4 py-4 px-3 alert alert-success" data-mdb-color="success" role="alert"></div>
		</div>
	</div>
</div>

<?php
include 'files/footer.php';
?>
<script>
$(document).ready(function(){

	let scanner = new Instascan.Scanner({ video: document.getElementById('preview'),mirror: false});
	Instascan.Camera.getCameras().then(function(cameras){
	   if(cameras.length > 0 ){
	       scanner.start(cameras[1]);
	   } else{
	       alert('No cameras found');
	   }
	}).catch(function(e) {
	   console.error(e);
	});

	scanner.addListener('scan',function(c){
		$.getJSON( "localdatabase.json", function(data) {
		    console.log('scanner worked');
		    for(let i = 0; i < data.length ; i++){
		    	console.log('scanner working');
			    if(data[i].NID == c){
			    	// console.log( data[i].NID );
					// console.log(c);
					$('#qrcode').val(c);
					$('.tutorial').hide();
					$('#userResult').show();
					$('.scanMessage').show();
					$('.scanMessage').removeClass('alert-danger');
					$('.scanMessage').addClass('alert-success');
					$('.scanMessage').html("Scan Success !");
					$('#empNameVal').html(data[i].Name);
					$('#emlDepVal').html(data[i].Depertment);
					$('#emlJobVal').html(data[i].Job);
					$('#emlBirthVal').html(data[i].Birth);
					$('#empNidVal').html(data[i].NID);
					$('#empPhoneVal').html(data[i].Phone);
					$('#empAddrVal').html(data[i].Address);
					$('#empEmailVal').html(data[i].Email);
					$('#empWebVal').html(data[i].Website);
					setInterval( function(){
						$('#qrcode').val("");
						$('.tutorial').show();
						$('#userResult').hide();
						$('.scanMessage').hide();
					}, 10000 );
			    }
			  //   else{
					// $('#qrcode').val("");
					// $('.tutorial').show();
					// $('#userResult').hide();
					// $('.scanMessage').show();
					// $('.scanMessage').removeClass('alert-success');
					// $('.scanMessage').addClass('alert-danger');
					// $('.scanMessage').html("Not Valid !");
			  //   }
		    }
		});
	});
});

</script>
</body>
</html>