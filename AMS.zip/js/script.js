$('.js-preloader').preloadinator({
	minTime: 2000
});