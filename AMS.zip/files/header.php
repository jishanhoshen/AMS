<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo $title; ?></title>
	<link rel="stylesheet" href="css/mdb.min.css">
	<link rel="stylesheet" href="css/preload.css">
	<link rel="stylesheet" href="css/fontawesome.all.css">
	<link rel="stylesheet" href="css/theme.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/menu.css">
	<link rel="stylesheet" href="css/footer.css">
</head>
<body>
<?php include 'nav.php';?>
<?php //include 'preload.php';?>
  <div class="mainContainer">
