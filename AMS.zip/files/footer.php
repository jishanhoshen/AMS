</div>
<footer class="footer theBox" id="footer">
    <div class="container">
        <span class="text-muted">Jishan Hoshen © 2021</span>
    </div>
</footer>
</div>
<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/mdb.min.js"></script>
<script src="js/jquery.preloadinator.js"></script>
<script src="js/fontawesome.all.js"></script>
<script src="js/dark.js"></script>
<script src="js/adapter.min.js"></script>
<script src="js/vue.min.js"></script>
<script src="js/instascan.min.js"></script>
<script src="js/script.js"></script>
