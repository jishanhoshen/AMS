<div class="preloader js-preloader flex-center" id="preloader">
	<div class="dots">
		<div class="dot"></div>
		<div class="dot"></div>
		<div class="dot"></div>
	</div>
</div>